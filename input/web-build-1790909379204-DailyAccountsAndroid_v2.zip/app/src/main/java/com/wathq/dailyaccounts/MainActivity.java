package com.wathq.dailyaccounts;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout root, content; TextView dateView, totals; String date;
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    TextView tv(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setPadding(dp(10),dp(8),dp(10),dp(8)); return t; }
    EditText input(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(true); e.setTextSize(17); e.setPadding(dp(10),dp(6),dp(10),dp(6)); return e; }

    @Override public void onCreate(Bundle b){ super.onCreate(b); db=new DB(this); date=today(); build(); }
    String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}

    void build(){
        ScrollView scroll=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(12),dp(12),dp(12),dp(24)); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); scroll.addView(root); setContentView(scroll);
        TextView title=tv("📒  الحسابات اليومية",26); title.setGravity(Gravity.CENTER); title.setTypeface(null,1); root.addView(title);
        TextView mark=tv("نسخة التطبيق 2.0 — نظام الحسابات اليومية",14); mark.setGravity(Gravity.CENTER); mark.setTextColor(Color.DKGRAY); root.addView(mark);
        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER_VERTICAL);
        Button prev=new Button(this); prev.setText("اليوم السابق"); Button next=new Button(this); next.setText("اليوم التالي");
        dateView=tv("",18); dateView.setGravity(Gravity.CENTER);
        nav.addView(prev,new LinearLayout.LayoutParams(0,dp(55),1)); nav.addView(dateView,new LinearLayout.LayoutParams(0,dp(55),1)); nav.addView(next,new LinearLayout.LayoutParams(0,dp(55),1)); root.addView(nav);
        prev.setOnClickListener(v->shift(-1)); next.setOnClickListener(v->shift(1));
        Button pick=new Button(this); pick.setText("📅 اختيار التاريخ"); pick.setOnClickListener(v->pickDate()); root.addView(pick);
        totals=tv("",17); totals.setBackgroundColor(Color.rgb(235,242,250)); root.addView(totals);
        addSection("شبكة"); addSection("نقد"); addSection("تحويل"); addSection("خرج");
        Button report=new Button(this); report.setText("📊 التقارير التفصيلية"); report.setOnClickListener(v->report()); root.addView(report);
        Button search=new Button(this); search.setText("🔎 بحث في العمليات"); search.setOnClickListener(v->search()); root.addView(search);
        refresh();
    }
    void addSection(String type){
        LinearLayout sec=new LinearLayout(this); sec.setOrientation(LinearLayout.VERTICAL); sec.setTag(type);
        TextView h=tv("【 "+type+" 】",20); h.setTypeface(null,1); h.setBackgroundColor(Color.LTGRAY); sec.addView(h);
        LinearLayout rows=new LinearLayout(this); rows.setOrientation(LinearLayout.VERTICAL); rows.setTag("rows"); sec.addView(rows);
        Button add=new Button(this); add.setText("＋ إضافة عملية في "+type); add.setOnClickListener(v->addDialog(type)); sec.addView(add); root.addView(sec);
    }
    void shift(int d){try{Calendar c=Calendar.getInstance(); c.setTime(new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(date)); c.add(Calendar.DATE,d); date=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime()); refresh();}catch(Exception ignored){}}
    void pickDate(){
        Calendar c=Calendar.getInstance(); try{c.setTime(new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(date));}catch(Exception ignored){}
        DatePickerDialog dlg=new DatePickerDialog(this,(v,y,m,day)->{date=String.format(Locale.US,"%04d-%02d-%02d",y,m+1,day);refresh();},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)); dlg.show();
    }
    void addDialog(String type){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(18),0,dp(18),0);
        EditText name=input(type.equals("خرج")?"التفاصيل":"نوع الخدمة / التفاصيل"); EditText amount=input("المبلغ بالريال"); amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); l.addView(name); l.addView(amount);
        new AlertDialog.Builder(this).setTitle("إضافة عملية — "+type).setView(l).setPositiveButton("حفظ",(d,w)->{double a=num(amount); if(a!=0||name.length()>0){db.add(date,type,name.getText().toString(),a);refresh();}}).setNegativeButton("إلغاء",null).show();
    }
    double num(EditText e){try{return Double.parseDouble(e.getText().toString());}catch(Exception x){return 0;}}
    void refresh(){
        dateView.setText("📅 "+date);
        for(int i=0;i<root.getChildCount();i++){View v=root.getChildAt(i); if(v instanceof LinearLayout && v.getTag()!=null){LinearLayout sec=(LinearLayout)v; LinearLayout rows=(LinearLayout)sec.getChildAt(1); rows.removeAllViews(); fill(rows,(String)sec.getTag());}}
        double a=db.sum(date,"شبكة"),b=db.sum(date,"نقد"),c=db.sum(date,"تحويل"),o=db.sum(date,"خرج");
        totals.setText(String.format(Locale.US,"شبكة: %.2f ريال   |   نقد: %.2f ريال\nتحويل: %.2f ريال   |   خرج: %.2f ريال\nالصافي: %.2f ريال",a,b,c,o,a+b+c-o));
    }
    void fill(LinearLayout rows,String type){
        Cursor c=db.rows(date,type); while(c.moveToNext()){long id=c.getLong(0); String name=c.getString(2); double a=c.getDouble(3); LinearLayout r=new LinearLayout(this); TextView x=tv(name+" — "+a+" ريال",16); r.addView(x,new LinearLayout.LayoutParams(0,dp(52),1)); Button e=new Button(this);e.setText("تعديل");e.setOnClickListener(v->editDialog(id));r.addView(e);Button q=new Button(this);q.setText("حذف");q.setOnClickListener(v->{new AlertDialog.Builder(this).setTitle("حذف العملية؟").setMessage("يمكنك الحذف بعد التأكيد.").setPositiveButton("حذف",(d,w)->{db.delete(id);refresh();}).setNegativeButton("إلغاء",null).show();});r.addView(q);rows.addView(r);} c.close();
    }
    void editDialog(long id){Cursor c=db.one(id);if(!c.moveToFirst()){c.close();return;}String name=c.getString(2);double val=c.getDouble(3);c.close();LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText n=input("التفاصيل");n.setText(name);EditText a=input("المبلغ");a.setText(String.valueOf(val));a.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);l.addView(n);l.addView(a);new AlertDialog.Builder(this).setTitle("تعديل العملية").setView(l).setPositiveButton("حفظ",(d,w)->{db.update(id,n.getText().toString(),num(a));refresh();}).setNegativeButton("إلغاء",null).show();}
    void report(){StringBuilder s=new StringBuilder("التاريخ: "+date+"\n\n");for(String t:new String[]{"شبكة","نقد","تحويل","خرج"}){s.append("【"+t+"】\n");Cursor c=db.rows(date,t);while(c.moveToNext())s.append("• "+c.getString(2)+": "+c.getDouble(3)+" ريال\n");c.close();s.append("الإجمالي: "+db.sum(date,t)+" ريال\n\n");}new AlertDialog.Builder(this).setTitle("📊 التقرير التفصيلي").setMessage(s).setPositiveButton("إغلاق",null).show();}
    void search(){
        EditText q=input("اكتب كلمة أو مبلغ للبحث"); new AlertDialog.Builder(this).setTitle("بحث في جميع العمليات").setView(q).setPositiveButton("بحث",(d,w)->{String term=q.getText().toString().trim();StringBuilder s=new StringBuilder();Cursor c=db.search(term);while(c.moveToNext())s.append(c.getString(1)).append(" — ").append(c.getString(2)).append(" — ").append(c.getString(3)).append(" — ").append(c.getDouble(4)).append(" ريال\n");c.close();if(s.length()==0)s.append("لا توجد نتائج.");new AlertDialog.Builder(this).setTitle("نتائج البحث").setMessage(s).setPositiveButton("إغلاق",null).show();}).setNegativeButton("إلغاء",null).show();
    }
    static class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"accounts.db",null,1);} public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,type TEXT,name TEXT,amount REAL)");} public void onUpgrade(SQLiteDatabase d,int a,int b){}
        void add(String date,String type,String name,double amount){ContentValues v=new ContentValues();v.put("date",date);v.put("type",type);v.put("name",name);v.put("amount",amount);getWritableDatabase().insert("tx",null,v);}
        void update(long id,String name,double amount){ContentValues v=new ContentValues();v.put("name",name);v.put("amount",amount);getWritableDatabase().update("tx",v,"id=?",new String[]{String.valueOf(id)});}
        void delete(long id){getWritableDatabase().delete("tx","id=?",new String[]{String.valueOf(id)});}
        double sum(String date,String type){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM tx WHERE date=? AND type=?",new String[]{date,type});double x=c.moveToFirst()?c.getDouble(0):0;c.close();return x;}
        Cursor rows(String date,String type){return getReadableDatabase().rawQuery("SELECT id,type,name,amount FROM tx WHERE date=? AND type=? ORDER BY id DESC",new String[]{date,type});}
        Cursor one(long id){return getReadableDatabase().rawQuery("SELECT id,type,name,amount FROM tx WHERE id=?",new String[]{String.valueOf(id)});}
        Cursor search(String term){String like="%"+term+"%";return getReadableDatabase().rawQuery("SELECT id,date,type,name,amount FROM tx WHERE date LIKE ? OR type LIKE ? OR name LIKE ? OR CAST(amount AS TEXT) LIKE ? ORDER BY id DESC",new String[]{like,like,like,like});}
    }
}
