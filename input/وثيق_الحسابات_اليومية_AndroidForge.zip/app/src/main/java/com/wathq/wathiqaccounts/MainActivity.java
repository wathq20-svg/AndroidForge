package com.wathq.wathiqaccounts;

import android.app.*;import android.os.*;import android.content.*;import android.database.Cursor;import android.database.sqlite.*;import android.graphics.*;import android.graphics.pdf.PdfDocument;import android.net.Uri;import android.view.*;import android.widget.*;import java.io.*;import java.text.*;import java.util.*;

public class MainActivity extends Activity{
 DB db; LinearLayout root; TextView totals,dateView; String date;
 int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
 TextView tv(String s,int z){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setPadding(dp(8),dp(8),dp(8),dp(8));return t;}
 EditText edit(String h){EditText e=new EditText(this);e.setHint(h);e.setSingleLine();e.setTextSize(16);return e;}
 public void onCreate(Bundle b){super.onCreate(b);db=new DB(this);date=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());build();}
 void build(){
  ScrollView sv=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(10),dp(10),dp(10),dp(20));sv.addView(root);setContentView(sv);
  TextView title=tv("📒 وثيق (الحسابات اليومية)",25);title.setGravity(Gravity.CENTER);root.addView(title);
  LinearLayout nav=new LinearLayout(this);Button p=new Button(this),n=new Button(this);p.setText("‹ السابق");n.setText("التالي ›");dateView=tv("",17);dateView.setGravity(Gravity.CENTER);
  nav.addView(p,new LinearLayout.LayoutParams(0,dp(52),1));nav.addView(dateView,new LinearLayout.LayoutParams(0,dp(52),1));nav.addView(n,new LinearLayout.LayoutParams(0,dp(52),1));root.addView(nav);
  p.setOnClickListener(v->shift(-1));n.setOnClickListener(v->shift(1));
  totals=tv("",17);totals.setBackgroundColor(Color.rgb(235,242,250));root.addView(totals);
  addSection("الشبكة","شبكة");addSection("النقد","نقد");addSection("التحويل","تحويل");addSection("الخرج","خرج");
  Button r=new Button(this);r.setText("📊 التقارير التفصيلية");r.setOnClickListener(v->report());root.addView(r);
  Button b=new Button(this);b.setText("💾 نسخة احتياطية");b.setOnClickListener(v->backup());root.addView(b);
  Button f=new Button(this);f.setText("📄 تصدير PDF");f.setOnClickListener(v->pdf());root.addView(f);
  Button c=new Button(this);c.setText("📑 تصدير البيانات");c.setOnClickListener(v->csv());root.addView(c);refresh();
 }
 void addSection(String title,String type){
  LinearLayout sec=new LinearLayout(this);sec.setOrientation(LinearLayout.VERTICAL);sec.setTag(type);
  TextView h=tv(title,20);h.setBackgroundColor(Color.LTGRAY);sec.addView(h);
  LinearLayout rows=new LinearLayout(this);rows.setOrientation(LinearLayout.VERTICAL);rows.setTag("rows");sec.addView(rows);
  Button add=new Button(this);add.setText("+ إضافة عملية");add.setOnClickListener(v->addDialog(type));sec.addView(add);root.addView(sec);
 }
 void shift(int d){try{Date x=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(date);Calendar c=Calendar.getInstance();c.setTime(x);c.add(Calendar.DATE,d);date=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());refresh();}catch(Exception e){}}
 void addDialog(String type){
  LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(18),0,dp(18),0);EditText name=edit(type.equals("خرج")?"التفاصيل":"نوع الخدمة");EditText amt=edit("المبلغ");amt.setInputType(2|8192);l.addView(name);l.addView(amt);
  new AlertDialog.Builder(this).setTitle("إضافة "+type).setView(l).setPositiveButton("حفظ",(d,w)->{double a=num(amt);if(a!=0||name.length()>0){db.add(date,type,name.getText().toString(),a);refresh();}}).setNegativeButton("إلغاء",null).show();
 }
 double num(EditText e){try{return Double.parseDouble(e.getText().toString());}catch(Exception x){return 0;}}
 void refresh(){
  dateView.setText("📅 "+date);
  for(int i=0;i<root.getChildCount();i++){View v=root.getChildAt(i);if(v instanceof LinearLayout && v.getTag()!=null){LinearLayout sec=(LinearLayout)v;LinearLayout rows=(LinearLayout)sec.getChildAt(1);rows.removeAllViews();fill(rows,(String)sec.getTag());}}
  double a=db.sum(date,"شبكة"),b=db.sum(date,"نقد"),c=db.sum(date,"تحويل"),o=db.sum(date,"خرج");totals.setText(String.format(Locale.US,"الشبكة %.2f | النقد %.2f | التحويل %.2f | الخرج %.2f\nالصافي %.2f ريال",a,b,c,o,a+b+c-o));
 }
 void fill(LinearLayout rows,String type){Cursor c=db.rows(date,type);while(c.moveToNext()){long id=c.getLong(0);String name=c.getString(2);double a=c.getDouble(3);LinearLayout r=new LinearLayout(this);TextView x=tv(name+" — "+a+" ريال",16);r.addView(x,new LinearLayout.LayoutParams(0,dp(48),1));Button e=new Button(this);e.setText("تعديل");e.setOnClickListener(v->editDialog(id));r.addView(e);Button q=new Button(this);q.setText("حذف");q.setOnClickListener(v->{db.delete(id);refresh();});r.addView(q);rows.addView(r);}c.close();}
 void editDialog(long id){Cursor c=db.one(id);if(!c.moveToFirst()){c.close();return;}String name=c.getString(2),type=c.getString(1);double val=c.getDouble(3);c.close();LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText n=edit("التفاصيل");n.setText(name);EditText a=edit("المبلغ");a.setText(String.valueOf(val));a.setInputType(2|8192);l.addView(n);l.addView(a);new AlertDialog.Builder(this).setTitle("تعديل العملية").setView(l).setPositiveButton("حفظ",(d,w)->{db.update(id,n.getText().toString(),num(a));refresh();}).setNegativeButton("إلغاء",null).show();}
 void report(){StringBuilder s=new StringBuilder("التاريخ: "+date+"\n\n");for(String t:new String[]{"شبكة","نقد","تحويل","خرج"}){s.append("【"+t+"】\n");Cursor c=db.rows(date,t);while(c.moveToNext())s.append("• "+c.getString(2)+": "+c.getDouble(3)+" ريال\n");c.close();s.append("الإجمالي: "+db.sum(date,t)+"\n\n");}new AlertDialog.Builder(this).setTitle("📊 التقرير التفصيلي").setMessage(s).setPositiveButton("إغلاق",null).show();}
 void backup(){write("daily_accounts_backup.csv","التاريخ,القسم,التفاصيل,القيمة\n");}
 void csv(){write("daily_accounts.csv","التاريخ,القسم,التفاصيل,القيمة\n");}
 void write(String name,String head){try{File f=new File(getExternalFilesDir(null),name);FileWriter w=new FileWriter(f);w.write(head);Cursor c=db.all();while(c.moveToNext())w.write(c.getString(1)+","+c.getString(2)+","+c.getString(3).replace(","," ") +","+c.getDouble(4)+"\n");c.close();w.close();share(f,"مشاركة الملف");}catch(Exception e){toast("تعذر التصدير");}}
 void pdf(){PdfDocument p=new PdfDocument();PdfDocument.Page q=p.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());Paint x=new Paint();x.setTextSize(18);q.getCanvas().drawText("Daily Accounts - "+date,30,45,x);q.getCanvas().drawText(totals.getText().toString().replace("\n"," "),30,80,x);p.finishPage(q);try{File f=new File(getExternalFilesDir(null),"report_"+date+".pdf");FileOutputStream o=new FileOutputStream(f);p.writeTo(o);o.close();p.close();share(f,"مشاركة PDF");}catch(Exception e){toast("تعذر إنشاء PDF");}}
 void share(File f,String title){Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_STREAM,Uri.parse("content://"+getPackageName()+".provider/"+f.getName()));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,title));}
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
 static class DB extends SQLiteOpenHelper{
  DB(Context c){super(c,"accounts.db",null,1);}public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,type TEXT,name TEXT,amount REAL)");}public void onUpgrade(SQLiteDatabase d,int a,int b){}
  void add(String d,String t,String n,double a){ContentValues v=new ContentValues();v.put("date",d);v.put("type",t);v.put("name",n);v.put("amount",a);getWritableDatabase().insert("tx",null,v);}
  void update(long id,String n,double a){ContentValues v=new ContentValues();v.put("name",n);v.put("amount",a);getWritableDatabase().update("tx",v,"id=?",new String[]{""+id});}
  void delete(long id){getWritableDatabase().delete("tx","id=?",new String[]{""+id});}
  double sum(String d,String t){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM tx WHERE date=? AND type=?",new String[]{d,t});double x=c.moveToFirst()?c.getDouble(0):0;c.close();return x;}
  Cursor rows(String d,String t){return getReadableDatabase().rawQuery("SELECT id,type,name,amount FROM tx WHERE date=? AND type=? ORDER BY id DESC",new String[]{d,t});}
  Cursor one(long id){return getReadableDatabase().rawQuery("SELECT id,type,name,amount FROM tx WHERE id=?",new String[]{""+id});}
  Cursor all(){return getReadableDatabase().rawQuery("SELECT id,date,type,name,amount FROM tx ORDER BY id",null);}
 }
}
