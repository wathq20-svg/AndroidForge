package com.wathq.wathiqaccounts;
import android.content.*;import android.database.Cursor;import android.net.Uri;import android.os.ParcelFileDescriptor;import java.io.*;
public class ShareProvider extends ContentProvider{
 public boolean onCreate(){return true;}
 public String getType(Uri u){return "application/octet-stream";}
 public ParcelFileDescriptor openFile(Uri u,String mode)throws FileNotFoundException{
  File f=new File(getContext().getExternalFilesDir(null),u.getLastPathSegment());
  return ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY);
 }
 public Cursor query(Uri u,String[] p,String s,String[] a,String so){return null;}
 public int delete(Uri u,String s,String[] a){return 0;} public int update(Uri u,ContentValues v,String s,String[] a){return 0;}
 public Uri insert(Uri u,ContentValues v){return null;}
}
